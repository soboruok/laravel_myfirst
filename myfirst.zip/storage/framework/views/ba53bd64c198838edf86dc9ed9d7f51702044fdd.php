<!--라라벨에서 제공하는 해더-->




<?php $__env->startSection('title'); ?>
    about
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<script> 

$(function() {
    $('.size').hide(); 
    $('#title').change(function(){
        if($('#title').val() == 'Custom') {
            $('.size').show(); 
        } else {
            $('.size').hide(); 
        } 
    });

    
    $('.package').hide(); 
    $('#packing').change(function(){
        if($('#packing').val() == 'wr' || $('#packing').val() == 'wf') {
            $('.package').show();
        } else {
            $('.package').hide(); 
        } 
    });

    $('.color').hide();
    $('#packing').change(function(){
        if($('#packing').val() == 'raw'){
            $('.color').hide(); 
           
        } else {
            $('.color').show(); 
        }
    })

});

</script>

<div class="row">
  <div class="col-2">
  </div>
  <div class="col-8">
        <h3> Weaving Machine  </h3>
        <a href="/weavings/create">
         <button type="submit" class="btn btn-success">Create Today's task</button>
        </a>
        <table class="table w-100">
        <thead>
            <tr>
                <th>Regdated Date</th>
                <th>Stage</th>
                <th>Title</th>
                <th>Size</th>
                <th>Machine</th>
                <th>Wiggle</th>
                <th>Color</th>
                <th>Q'ty</th>
                <th>Select</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $weavinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weavinglist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($weavinglist->created_at); ?></td>
                <td><?php echo e($weavinglist->packing); ?></td>
                <td><?php echo e($weavinglist->title); ?></td>
                <td><?php echo e($weavinglist->size); ?></td>
                <td><?php echo e($weavinglist->machine); ?></td>
                <td><?php echo e($weavinglist->wiggle); ?></td>
                <td><?php echo e($weavinglist->color); ?></td>
                <td><?php echo e($weavinglist->qty); ?></td>
                <td>
                <div class="form-group">
                    <a href="/weavings/<?php echo e($weavinglist->id); ?>">
                        <button type="submit" class="btn btn-primary">View</button>
                    </a>
                </div>
            
                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

  </div>
  <div class="col-2"></div>
</div>


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfirst\resources\views/weaving/index.blade.php ENDPATH**/ ?>