<!--라라벨에서 제공하는 해더-->




<?php $__env->startSection('title'); ?>
    about
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row mt-10">
  <div class="col-2">
  </div>
  <div class="col-8">
        <h3> Weaving Machine  </h3>
        <form action="/weavings/<?php echo e($weavingID->id); ?>" method="POST">
        <!--CSRF Protection -->
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="title">Mat Name</label>
                <select class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="title" name="title" >
                    <option value="">Select Mat</option>
                    <option value="Family"  <?php echo e($weavingID->title=='Family'  ? 'selected' : ''); ?>>Family Size</option>
                    <option value="Olympic" <?php echo e($weavingID->title=='Olympic' ? 'selected' : ''); ?>>Olympic Size</option>
                    <option value="Elite"   <?php echo e($weavingID->title=='Elite'   ? 'selected' : ''); ?>>Olympic Elite Size</option>
                    <option value="Custom"  <?php echo e($weavingID->title=='Custom'  ? 'selected' : ''); ?>>Custom Size</option>
                </select>

                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            

            <div class="form-group w-75 p-3 p-1 size">
                <label for="size">Mat Size</label>
                <input type="text" class="form-control <?php if ($errors->has('size')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('size'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="size" 
                name="size"  value="<?php echo e(old('size')?old('size'): $weavingID->size); ?>"> 
               
            </div>

            <div class="form-group">
                <label for="machine">Which Machine?</label>
                <select class="form-control <?php if ($errors->has('machine')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('machine'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="machine" name="machine"  >
                    <option value="">Select Machine</option>
                    <option value="OL" <?php echo e($weavingID->machine=='OL' ? 'selected' : ''); ?>>OLD LOOM</option>
                    <option value="NL" <?php echo e($weavingID->machine=='NL' ? 'selected' : ''); ?>>NEW LOOM</option>
                    <option value="AL" <?php echo e($weavingID->machine=='AL' ? 'selected' : ''); ?>>AUTO LOOM</option>
                </select>
                <?php if ($errors->has('machine')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('machine'); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label for="packing">Package</label>
                <select class="form-control <?php if ($errors->has('packing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('packing'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="packing" name="packing" >
                    <option value="">Select Package</option>
                    <option value="raw" <?php echo e($weavingID->packing=='raw' ? 'selected' : ''); ?>>Raw</option>
                    <option value="nwr" <?php echo e($weavingID->packing=='nwr' ? 'selected' : ''); ?>>no wiggles(Roll)</option>
                    <option value="nwf" <?php echo e($weavingID->packing=='nwf' ? 'selected' : ''); ?>>no wiggles(Fold)</option>
                    <option value="wr"  <?php echo e($weavingID->packing=='wr' ? 'selected' : ''); ?>>wiggled(Roll)</option>
                    <option value="wf"  <?php echo e($weavingID->packing=='wf' ? 'selected' : ''); ?>>wiggled(Fold)</option>
                </select>

                <div class="form-group w-75 p-3 p-1 package">
                    <input type="text" class="form-control <?php if ($errors->has('wiggle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('wiggle'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="wiggle" 
                    name="wiggle"  value="<?php echo e(old('wiggle')?old('wiggle'):$weavingID->wiggle); ?>"> 
                </div>

                <?php if ($errors->has('wiggle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('wiggle'); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group color">
                <label for="color">Color</label>
                <select class="form-control <?php if ($errors->has('color')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('color'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="color" name="color">
                    <option value="">Select color</option>
                    <option value="green"   <?php echo e($weavingID->color=='green' ? 'selected' : ''); ?>>Green</option>
                    <option value="blue"    <?php echo e($weavingID->color=='blue' ? 'selected' : ''); ?>>Blue</option>
                    <option value="yellow"  <?php echo e($weavingID->color=='yellow' ? 'selected' : ''); ?>>Yellow</option>
                    <option value="black"   <?php echo e($weavingID->color=='black' ? 'selected' : ''); ?>>Black</option>
                </select>
               
            </div>
            

            <div class="form-group">
                <label for="Title">Q'ty</label> 
                <select class="form-control <?php if ($errors->has('qty')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('qty'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="qty" name="qty">
                    <option value="">Select Q'ty</option>
                    <option value="1" <?php echo e($weavingID->qty==1 ? 'selected' : ''); ?>>1</option>
                    <option value="2" <?php echo e($weavingID->qty==2 ? 'selected' : ''); ?>>2</option>
                    <option value="3" <?php echo e($weavingID->qty==3 ? 'selected' : ''); ?>>3</option>
                    <option value="4" <?php echo e($weavingID->qty==4 ? 'selected' : ''); ?>>4</option>
                    <option value="5" <?php echo e($weavingID->qty==5 ? 'selected' : ''); ?>>5</option>
                </select>
                <?php if ($errors->has('qty')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('qty'); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label for="memo">Memo:</label>
                <textarea class="form-control <?php if ($errors->has('memo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('memo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" rows="5" id="memo" name="memo" >
                <?php echo e(old('memo') ? old('memo') :$weavingID->memo); ?>

                </textarea>
                
            </div>



            
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <!-- 유효성체크 -->
        <?php if($errors->any()): ?>
            <?php echo e($errors); ?>

        <?php endif; ?>
  </div>
  <div class="col-2"></div>
</div>


    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfirst\resources\views/Weaving/edit.blade.php ENDPATH**/ ?>