<!--라라벨에서 제공하는 해더-->


<?php $__env->startSection('title'); ?>
    about
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<script> 

$(function() {
    $('.size').hide(); 
    $('#title').change(function(){
        if($('#title').val() == 'Custom') {
            $('.size').show(); 
        } else {
            $('.size').hide(); 
        } 
    });

    
    $('.package').hide(); 
    $('#packing').change(function(){
        if($('#packing').val() == 'wr' || $('#packing').val() == 'wf') {
            $('.package').show();
        } else {
            $('.package').hide(); 
        } 
    });

    $('.color').hide();
    $('#packing').change(function(){
        if($('#packing').val() == 'raw'){
            $('.color').hide(); 
           
        } else {
            $('.color').show(); 
        }
    })

});




</script>

<div class="row mt-10">
  <div class="col-1">
  </div>
  <div class="col-10">
        <h3> Things to do  </h3>
        <form action="/weavings" method="POST">
        <!--CSRF Protection -->
        <?php echo csrf_field(); ?>
            <div class="form-group p-3 border bg-info">
                <h4> Work Order   </h4>
                <select multiple class="form-control <?php if ($errors->has('cat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cat'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                name="cat"  value="<?php echo e(old('cat')?old('cat'):''); ?>" id="cat">
                    <option selected></option>
                    <?php $__currentLoopData = $catlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>">
                  
                    <?php echo e($cat->cat); ?>( <?php echo e($cat->no); ?> ) / 
                    <?php echo e($cat->packing); ?> /
                    <?php echo e($cat->title); ?>( <?php echo e($cat->size); ?> )
                    <?php echo e($cat->color); ?> / ( <?php echo e($cat->wiggle); ?> ) /
                    <?php echo e("Remaining:". $cat->qty); ?> EA
                    
                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               
                <?php if ($errors->has('cat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cat'); ?>
                    <?php echo e("Please select Work Order"); ?>

                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label for="title">Mat Name</label>
                <select class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="title" 
                name="title" value="<?php echo e(old('title')?old('title'):''); ?>">
                    <option selected></option>
                    <option value="Family">Family Size</option>
                    <option value="Olympic">Olympic Size</option>
                    <option value="Elite">Olympic Elite Size</option>
                    <option value="Custom">Custom Size</option>
                </select>

                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                    <?php echo e("Please select Mat"); ?>

                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            

            <div class="form-group w-75 p-3 p-1 size">
                <label for="size">Mat Size</label>
                <input type="text" class="form-control <?php if ($errors->has('size')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('size'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="size" 
                name="size" placeholder="Enter size" value="<?php echo e(old('size')?old('size'):''); ?>"> 
               
            </div>

            <div class="form-group">
                <label for="machine">Which Machine?</label>
                <select class="form-control <?php if ($errors->has('machine')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('machine'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="machine" 
                name="machine" value="<?php echo e(old('machine')?old('machine'):''); ?>">
                    <option slected></option>
                    <option value="OL">OLD LOOM</option>
                    <option value="NL">NEW LOOM</option>
                    <option value="AL">AUTO LOOM</option>
                </select>
                <?php if ($errors->has('machine')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('machine'); ?>
                    <?php echo e("Please select machine"); ?>

                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label for="packing">Stage</label>
                <select class="form-control <?php if ($errors->has('packing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('packing'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="packing" 
                name="packing" value="<?php echo e(old('packing')?old('packing'):''); ?>">
                    <option slected></option>
                    <option value="raw">Raw</option>
                    <option value="nwr">no wiggles(Roll)</option>
                    <option value="nwf">no wiggles(Fold)</option>
                    <option value="wr">wiggled(Roll)</option>
                    <option value="wf">wiggled(Fold)</option>
                </select>
                <?php if ($errors->has('packing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('packing'); ?>
                    <?php echo e("Please select Stage"); ?>

                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <div class="form-group w-75 p-3 p-1 package">
                    <input type="text" class="form-control <?php if ($errors->has('wiggle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('wiggle'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="wiggle" 
                    name="wiggle" placeholder="Enter wiggle pattern" value="<?php echo e(old('wiggle')?old('wiggle'):''); ?>"> 
                </div>
            </div>

            <div class="form-group color">
                <label for="color">Color</label>
                <select class="form-control <?php if ($errors->has('color')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('color'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="color" 
                name="color" value="<?php echo e(old('color')?old('color'):''); ?>">
                    <option slected></option>
                    <option value="green">Green</option>
                    <option value="blue">Blue</option>
                    <option value="yellow">Yellow</option>
                    <option value="black">Black</option>
                </select>
               
            </div>
            

            <div class="form-group">
                <label for="Title">Q'ty</label> 
                <select class="form-control <?php if ($errors->has('qty')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('qty'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="qty" 
                name="qty" value="<?php echo e(old('qty')?old('qty'):''); ?>">
                    <option slected></option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
                <?php if ($errors->has('qty')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('qty'); ?>
                    <?php echo e("Please select Q'ty"); ?>

                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label for="memo">Memo:</label>
                <textarea class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" rows="5" id="memo" name="memo" placeholder="Enter memo">
                <?php echo e(old('memo') ? old('memo') :''); ?>

                </textarea>
                
            </div>



            
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <!-- 유효성체크 -->
        <!--
        <?php if($errors->any()): ?>
            <?php echo e($errors); ?>

        <?php endif; ?>
        -->
  </div>
  <div class="col-1"></div>
</div>


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfirst\resources\views/weaving/create.blade.php ENDPATH**/ ?>