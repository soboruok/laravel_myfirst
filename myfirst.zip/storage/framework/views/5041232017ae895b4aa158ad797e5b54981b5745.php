<!--라라벨에서 제공하는 해더-->




<?php $__env->startSection('title'); ?>
    about
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-2">
  </div>
  <div class="col-8">
        <h3> WORK ORDER </h3>
       
        <table class="table w-100">
        <thead>
            <tr>
                <th>Category/Number</th>
                <th>title</th>
                <th>size</th>
                <th>color</th>
                <th>packing</th>
                <th>wiggle</th>
                <th>Quota</th>
                <th>Remaining</th>
                <th>Status</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $catlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($catlist->cat); ?>/<?php echo e($catlist->no); ?></td>
                <td><?php echo e($catlist->title); ?></td>
                <td><?php echo e($catlist->size); ?></td>
                <td><?php echo e($catlist->color); ?></td>
                <td><?php echo e($catlist->packing); ?></td>
                <td><?php echo e($catlist->wiggle); ?></td>
                <td><?php echo e($catlist->status); ?></td>
                <td><?php echo e($catlist->qty); ?></td>
                <td><a href="/cats/<?php echo e($catlist -> id); ?>">Details</a></td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

  </div>
  <div class="col-2"></div>
</div>


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfirst\resources\views/cat/index.blade.php ENDPATH**/ ?>