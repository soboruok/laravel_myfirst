<!--라라벨에서 제공하는 해더-->




<?php $__env->startSection('title'); ?>
    about
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-2">
  </div>
  <div class="col-8">
        <?php $__currentLoopData = $orderNo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderNo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($orderNo->cat); ?>:<?php echo e($orderNo->no); ?>, Quota : <?php echo e($orderNo->status); ?> </h3>
       
        <table class="table w-100">
        <thead>
            <tr>
                <th>Date</th>
                <th>Stage</th>
                <th>title</th>
                <th>size</th>
                <th>color</th>
                <th>wiggle</th>
                <th>Completed</th>
                <th>memo</th>
            </tr>
        </thead>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $orderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($orderlist->created_at); ?></td>
                <td>
                    <?php  if ($orderlist->packing=='raw'){ ?>
                        <?php echo e("Making Mat"); ?>

                    <?php   }  ?>

                    


                </td>
                <td><?php echo e($orderlist->title); ?></td>
                <td><?php echo e($orderlist->size); ?></td>
                <td><?php echo e($orderlist->color); ?></td>
                <td><?php echo e($orderlist->wiggle); ?></td>
                <td><?php echo e($orderlist->qty); ?></td>
                <td><?php echo e($orderlist->memo); ?></td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

  </div>
  <div class="col-2"></div>
</div>


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfirst\resources\views/cat/show.blade.php ENDPATH**/ ?>