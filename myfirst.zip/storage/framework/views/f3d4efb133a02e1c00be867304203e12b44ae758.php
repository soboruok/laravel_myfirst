<!--라라벨에서 제공하는 해더-->


<?php $__env->startSection('title'); ?>
   weaving
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="row">
  <div class="col-2"></div>
  <div class="col-8">
    <h3> Today's Tasks  </h3>
    
    <a href="/weavings/create">
        <button type="submit" class="btn btn-success">Create Today's task</button>
    </a>
    <a href="/weavings">
        <button type="submit" class="btn btn-dark">View All task</button>
    </a>

    <table class="table w-100">
        <thead>
        <tr>
            <th>title</th>
            <th>size</th>
            <th>machine</th>
            <th>packing</th>
            <th>wiggle</th>
            <th>color</th>
            <th>qty</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td><?php echo e($weavingID->title); ?></td>
            <td><?php echo e($weavingID->size); ?></td>
            <td><?php echo e($weavingID->machine); ?></td>
            <td><?php echo e($weavingID->packing); ?></td>
            <td><?php echo e($weavingID->wiggle); ?></td>
            <td><?php echo e($weavingID->color); ?></td>
            <td><?php echo e($weavingID->qty); ?></td>
        </tr>
        </tbody>
        <tbody>
        <tr>
            <th colspan="7">Memo</th>
        </tr>
        <tr>
            <td colspan="7">
                <?php echo e($weavingID->memo); ?>

            </td>
        </tr>
        </tbody>
    </table>

    <div class="form-group">
        <a href="/weavings/<?php echo e($weavingID->id); ?>/edit">
            <button type="submit" class="btn btn-primary">Edit</button>
        </a>
        <form method="Post" action="/weavings/<?php echo e($weavingID->id); ?>" class="float-right">
            <?php echo csrf_field(); ?>
            <?php echo method_field('Delete'); ?>
            <button type="submit" class="btn btn-danger">Del</button>
        </form>
    </div>
    
  </div>

  </div>
  <div class="col-2"></div>
</div>



    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myfirst\resources\views/Weaving/show.blade.php ENDPATH**/ ?>